#!/bin/bash

# Issue Deduplicator Library Functions
# Core functions for detecting and managing duplicate GitHub issues

# Fetch all open issues from repository
fetch_all_issues() {
    local org="$1"
    local repo="$2"
    local limit="${3:-1000}"
    
    # Use the provided gh command - returns newest first
    gh issue list \
        --repo "$org/$repo" \
        --limit "$limit" \
        -s open \
        --json number,title,createdAt,author,url 2>/dev/null || echo "[]"
}

# Normalize title for comparison
normalize_title() {
    local title="$1"
    
    # Convert to lowercase
    title=$(echo "$title" | tr '[:upper:]' '[:lower:]')
    
    # Remove special characters except spaces
    title=$(echo "$title" | sed 's/[^a-z0-9 ]//g')
    
    # Remove common stop words
    local stop_words="the a an is are was were be been being have has had do does did will would could should may might must can could shall to of in for on at with by from about into through during before after above below between under over"
    
    for word in $stop_words; do
        title=$(echo "$title" | sed "s/\b$word\b//g")
    done
    
    # Remove extra spaces and trim
    title=$(echo "$title" | tr -s ' ' | sed 's/^ *//;s/ *$//')
    
    echo "$title"
}

# Calculate Levenshtein distance as percentage similarity
calculate_levenshtein() {
    local str1="$1"
    local str2="$2"
    
    # If strings are identical
    if [[ "$str1" == "$str2" ]]; then
        echo "100"
        return
    fi
    
    local len1=${#str1}
    local len2=${#str2}
    
    # If one string is empty
    if [[ $len1 -eq 0 ]]; then
        echo "0"
        return
    fi
    if [[ $len2 -eq 0 ]]; then
        echo "0"
        return
    fi
    
    # Simple approximation for Levenshtein
    # Count matching characters in order
    local matches=0
    local min_len=$len1
    if [[ $len2 -lt $min_len ]]; then
        min_len=$len2
    fi
    
    for ((i=0; i<$min_len; i++)); do
        if [[ "${str1:$i:1}" == "${str2:$i:1}" ]]; then
            ((matches++))
        fi
    done
    
    # Calculate percentage based on longer string
    local max_len=$len1
    if [[ $len2 -gt $max_len ]]; then
        max_len=$len2
    fi
    
    local percentage=$((matches * 100 / max_len))
    echo "$percentage"
}

# Calculate token overlap percentage (Jaccard similarity)
calculate_token_overlap() {
    local str1="$1"
    local str2="$2"
    
    # Split into tokens
    local -a tokens1=($str1)
    local -a tokens2=($str2)
    
    # If either is empty
    if [[ ${#tokens1[@]} -eq 0 ]] || [[ ${#tokens2[@]} -eq 0 ]]; then
        echo "0"
        return
    fi
    
    # Count intersection
    local intersection=0
    for token1 in "${tokens1[@]}"; do
        for token2 in "${tokens2[@]}"; do
            if [[ "$token1" == "$token2" ]]; then
                ((intersection++))
                break
            fi
        done
    done
    
    # Count union (total unique tokens)
    local -a all_tokens=("${tokens1[@]}" "${tokens2[@]}")
    local -a unique_tokens=()
    for token in "${all_tokens[@]}"; do
        local found=0
        for unique in "${unique_tokens[@]}"; do
            if [[ "$token" == "$unique" ]]; then
                found=1
                break
            fi
        done
        if [[ $found -eq 0 ]]; then
            unique_tokens+=("$token")
        fi
    done
    
    local union=${#unique_tokens[@]}
    
    # Calculate Jaccard similarity
    if [[ $union -eq 0 ]]; then
        echo "0"
    else
        local percentage=$((intersection * 100 / union))
        echo "$percentage"
    fi
}

# Calculate weighted similarity score
similarity_score() {
    local title1="$1"
    local title2="$2"
    
    # Normalize titles
    local norm1=$(normalize_title "$title1")
    local norm2=$(normalize_title "$title2")
    
    # If normalized titles are identical
    if [[ "$norm1" == "$norm2" ]]; then
        echo "100"
        return
    fi
    
    # Calculate Levenshtein similarity (70% weight)
    local lev_score=$(calculate_levenshtein "$norm1" "$norm2")
    
    # Calculate token overlap (30% weight)
    local token_score=$(calculate_token_overlap "$norm1" "$norm2")
    
    # Weighted average
    local final_score=$(( (lev_score * 70 + token_score * 30) / 100 ))
    
    echo "$final_score"
}

# Find duplicate groups based on threshold
find_duplicate_groups() {
    local issues_json="$1"
    local threshold="${2:-85}"
    
    # Parse issues into array
    local issue_count=$(echo "$issues_json" | jq 'length')
    
    if [[ $issue_count -eq 0 ]]; then
        echo "[]"
        return
    fi
    
    # Build similarity groups
    local groups="[]"
    local processed=""
    
    for ((i=0; i<$issue_count; i++)); do
        # Skip if already processed
        if [[ "$processed" == *",$i,"* ]]; then
            continue
        fi
        
        local issue_i=$(echo "$issues_json" | jq ".[$i]")
        local title_i=$(echo "$issue_i" | jq -r '.title')
        local number_i=$(echo "$issue_i" | jq -r '.number')
        
        # Start new group with this issue
        local group="[$number_i"
        local has_duplicates=false
        
        # Compare with remaining issues
        for ((j=i+1; j<$issue_count; j++)); do
            # Skip if already processed
            if [[ "$processed" == *",$j,"* ]]; then
                continue
            fi
            
            local issue_j=$(echo "$issues_json" | jq ".[$j]")
            local title_j=$(echo "$issue_j" | jq -r '.title')
            local number_j=$(echo "$issue_j" | jq -r '.number')
            
            # Calculate similarity
            local score=$(similarity_score "$title_i" "$title_j")
            
            if [[ $score -ge $threshold ]]; then
                group="$group,$number_j"
                processed="$processed,$j,"
                has_duplicates=true
            fi
        done
        
        group="$group]"
        processed="$processed,$i,"
        
        # Only add groups with duplicates
        if [[ "$has_duplicates" == "true" ]]; then
            if [[ "$groups" == "[]" ]]; then
                groups="[$group]"
            else
                groups="${groups%]}, $group]"
            fi
        fi
    done
    
    echo "$groups"
}

# Process a duplicate group to identify keeper and duplicates
process_duplicate_group() {
    local issues_json="$1"
    local group="$2"
    
    # Parse group (array of issue numbers)
    local group_numbers=$(echo "$group" | tr -d '[]' | tr ',' ' ')
    
    # Find the newest issue (remember: list is already sorted newest first)
    local newest_number=""
    local newest_date=""
    
    for number in $group_numbers; do
        local issue=$(echo "$issues_json" | jq ".[] | select(.number == $number)")
        local created_at=$(echo "$issue" | jq -r '.createdAt')
        
        if [[ -z "$newest_date" ]] || [[ "$created_at" > "$newest_date" ]]; then
            newest_date="$created_at"
            newest_number="$number"
        fi
    done
    
    # Build result with keeper and duplicates
    local result="{\"keeper\": $newest_number, \"duplicates\": ["
    local first=true
    
    for number in $group_numbers; do
        if [[ "$number" != "$newest_number" ]]; then
            if [[ "$first" == "false" ]]; then
                result="$result, "
            fi
            result="$result$number"
            first=false
        fi
    done
    
    result="$result]}"
    echo "$result"
}

# Export functions if sourced in test mode
if [[ "$TEST_MODE" == "true" ]]; then
    export -f fetch_all_issues
    export -f normalize_title
    export -f calculate_levenshtein
    export -f calculate_token_overlap
    export -f similarity_score
    export -f find_duplicate_groups
    export -f process_duplicate_group
fi